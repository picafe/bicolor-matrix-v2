G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-08-20T20:04:03-04:00*
G04 #@! TF.ProjectId,button-board-r2,62757474-6f6e-42d6-926f-6172642d7232,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-08-20 20:04:03*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.244000X0.244000X0.269000X-0.244000X0.269000X-0.244000X-0.269000X0.244000X-0.269000X0*%
%ADD11R,1.700000X1.700000*%
%ADD12O,1.700000X1.700000*%
%ADD13R,0.650000X0.450000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,C1*
X144410000Y-104750000D03*
X142850000Y-104750000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J1*
X105085000Y-113595000D03*
D12*
X105085000Y-111055000D03*
X105085000Y-108515000D03*
X105085000Y-105975000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,U1*
X142720000Y-106050000D03*
X142720000Y-106700000D03*
X142720000Y-107350000D03*
X144480000Y-107350000D03*
X144480000Y-106700000D03*
X144480000Y-106050000D03*
G04 #@! TD*
M02*
